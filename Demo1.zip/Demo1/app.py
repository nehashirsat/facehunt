from flask import Flask,render_template,request,session,url_for, redirect
from werkzeug.utils import secure_filename
import os
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key="teraGharChalaJayenga"
#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/Facehunt'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mango.db'
db = SQLAlchemy(app)


#Police_Station

class PoliceStation(db.Model):
    id = db.Column(db.String, unique=True, primary_key=True)
    username = db.Column(db.String(20))
    password = db.Column(db.String(20))
    policestation = db.Column(db.String(200))
    location = db.Column(db.String(200))
    gmail = db.Column(db.String(20))


# Police Station Registration
@app.route("/AddPolice", methods=['POST','GET'])
def insert():
    if request.method == 'POST':
        id=request.form.get('id')
        username = request.form.get('username')
        password = request.form.get('password')
        policestation= request.form.get('policestation')
        location = request.form.get('location')
        gmail = request.form.get('gmail')

        entry = PoliceStation(id=id,username=username, password=password,policestation=policestation,location=location,gmail=gmail)

        db.create_all()         #for creating table if doesn't exist
        db.session.add(entry)   #inserting data into the table
        db.session.commit()

    else:
        return  render_template('AddPolice.html')

    return render_template('Admindashboard.html')


# add police station
@app.route("/showdetails")
def showdetails():
    alldetails = PoliceStation.query.all()
    return render_template("policeview.html", alldetails=alldetails)


# police station login
@app.route("/policestation", methods=['GET', 'POST'])
def userlogin():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        try:

            insert = PoliceStation.query.filter_by(username=username).first_or_404()

        except:
            msg = "Invalid Credentials"
            return render_template('policestation.html', msg=msg)

        if password == insert.password:
            session["user"] = username
            return render_template("/policedashboard.html")
        else:
            msg = "Invalid Credentials"
            return render_template('index.html', msg=msg)

    return render_template("/index.html")


#Criminals and missing person records store in records table

class Records(db.Model):
    id = db.Column(db.String, unique=True, primary_key=True)
    name = db.Column(db.String(20))
    role = db.Column(db.String(20))
    photo = db.Column(db.String(200))
    description = db.Column(db.LargeBinary)

# Function to handle file uploads
def upload_file():
    if 'file' not in request.files:
        # No file part in the request
        return None

    file = request.files['file']

    if file.filename == '':
        # No selected file
        return None

    if file:
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return filename

# Complaint Registration
@app.route("/filecomplaint", methods=['POST','GET'])
def filecomplaintPolice():
    if request.method == 'POST':
        id = request.form.get('id')
        name = request.form.get('name')
        role = request.form.get('role')
        description = request.form.get('description')
        photo = upload_file()  # Get the filename of the uploaded image

        entry = Records(id=id, name=name, role=role, photo=photo, description=description)

        db.session.add(entry)   # Inserting data into the table
        db.session.commit()

        return render_template('policedashboard.html')
    else:
        return render_template('filecomplaint.html')

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/contact")
def contact():
    return render_template("contacts.html")

@app.route("/admin.html")
def viewadminloginpage():
    return render_template("admin.html")

@app.route("/policestation.html")
def viewpoliceloginpage():
    return render_template("policestation.html")

@app.route("/viewpolice")
def viewpolice():
    return render_template("policeview.html")

@app.route("/addpolice")
def addpolice():
    return render_template("AddPolice.html")

@app.route("/notification")
def notification():
    return render_template("alert.html")

@app.route("/filecomplaint")
def filecomplaint():
    return render_template("filecomplaint.html")

@app.route("/policekaview")
def policekaview():
    return render_template("view.html")


@app.route("/adminlogin", methods = ['POST','GET'])
def adminlogin():
    if request.method == 'POST':
        adminuser = request.form.get('ausername')
        adminpass = request.form.get('apassword')

        if(adminuser=="admin@123" and adminpass=="khula123"):
            session['usern'] = adminuser
            return render_template('Admindashboard.html')
        else:
            msg = "Invalid Credentials"
            return render_template('admin.html', msg=msg)
    return render_template('admin.html')

if __name__ == "__main__":
    app.run(debug=True)